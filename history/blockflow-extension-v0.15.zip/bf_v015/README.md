# BlockFlow Automation MVP 0.13

Lokális Chrome extension weboldal-automatizáláshoz.

## v0.13 újdonságok

- A középső Apple Shortcuts-szerű blokkokon a fő opciók közvetlenül szerkeszthetők.
- A `Kattints`, `Nyerd ki`, `Beillesztés`, `Várakozás`, `Ha`, `Ismételd`, `Popup`, `Email`, `Maszkolás`, `Minden sorra` blokkok fő mezői a blokk-kártyán elérhetők.
- A cél elem kiválasztása most a középső blokkon is elérhető külön gombbal.
- A jobb oldali beállításpanel önállóan görgethető, a középső blokklista is önállóan görgethető.
- Blokk kijelölésekor a jobb oldali beállításpanel automatikusan a kiválasztott blokk beállításaihoz ugrik.
- A jobb oldali panel tetején sticky kiválasztott blokk fejléc segít hosszú workflow-knál.

## Telepítés

1. Csomagold ki a ZIP-et.
2. Chrome: `chrome://extensions`
3. Kapcsold be a Developer mode-ot.
4. Load unpacked.
5. Válaszd ki a kicsomagolt mappát.

## Fontos

Az `Elem kiválasztása az oldalról` útvonal megmaradt: a builderből indított picker a cél weboldal tabra fókuszál, hover keretet mutat, és a kiválasztott elem descriptorát menti.


## v0.14

- Fixed collapsed toolbar popup by adding popup-specific sizing and overflow overrides.
- Builder/sidebar/element picker logic unchanged from v0.13.
