# BlockFlow v0.19

Lokális Chrome extension weboldal-automatizáláshoz.

## v0.19 javítás

- A Figyelő trigger blokkoknál a scope részletei is látszanak és szerkeszthetők.
- Domain/path/pontos URL/URL tartalmazza mezők közvetlenül a blokkban és a jobb oldali beállításokban is elérhetők.
- A jobb oldali panelen megjelenik az aktuális scope összefoglalója.
- Gyors gomb: jelenlegi oldal domain/path/URL adatainak kitöltése.

## Telepítés

1. Chrome: chrome://extensions
2. Developer mode bekapcsolása
3. Load unpacked
4. A kicsomagolt mappa kiválasztása


## v0.19
- Régi Figyelő: szöveg / Figyelő: elem blokkok automatikus migrációja új Figyelő trigger + feltétel modellre.
- Új figyelő feltételblokkok: szöveg, elem, mezőérték, URL.
- Figyelő trigger logika: minden / bármelyik / egyik sem.
- Builder felső gombsora ikonokat kapott.
