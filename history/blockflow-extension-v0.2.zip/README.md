# BlockFlow Automation MVP 0.2

Lokális Chrome extension Scratch-inspirált blokkos weboldal-automatizáláshoz.

## Telepítés

1. Csomagold ki a ZIP-et.
2. Chrome: `chrome://extensions`
3. Developer mode: bekapcsolva
4. Load unpacked
5. Válaszd ki a `blockflow-extension` mappát.

## Fő funkciók

- Popup gyorsindító
- Sidebar aktuális weboldalhoz
- Teljes oldalas blokkos Builder
- Elemkiválasztás weboldalon hover + kattintás móddal
- Workflow import/export JSON formátumban
- Dry-run futtatás
- Stop gomb
- Jobb selector újrakeresés pontozással
- Változók: `{{nev}}`, `{{email}}`, `{{popup_szoveg}}`
- Email előkészítés `mailto:` linkkel
- Hosszú email törzs automatikusan vágólapra kerül

## Blokkok

- Indítás
- Figyeld a szöveget
- Figyeld az elemet
- Kattintás
- Beillesztés / kitöltés
- Adat kinyerése
- Várakozás
- Ha...
- Ismételd...
- Várj popupra
- Popup adat kinyerése
- Popup gomb
- Vágólapra másolás
- Email összeállítása
- Email megnyitása

## Fontos működés

Az extension nem küld emailt. Csak megnyitja az alapértelmezett email klienst `mailto:` linkkel. Ha az email törzse túl hosszú a linkhez, a törzset vágólapra másolja.

A `Ha...` blokk hamis feltételnél az utána következő N blokkot ugorja át.

Az `Ismételd...` blokk az utána következő N blokkot futtatja újra a beállított alkalommal.

Importált workflow alapból nem ellenőrzött. Első éles futtatás előtt Dry-run javasolt.
