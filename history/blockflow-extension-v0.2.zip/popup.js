let workflows = [];
const $ = s => document.querySelector(s);
async function init(){ const store = await BF.getStore(); workflows = store.workflows; $('#workflowSelect').innerHTML = workflows.map(w=>`<option value="${w.id}" ${w.id===store.activeWorkflowId?'selected':''}>${w.name}</option>`).join(''); }
$('#openBuilder').onclick = () => chrome.runtime.sendMessage({ type:'OPEN_BUILDER' });
$('#openSide').onclick = () => chrome.runtime.sendMessage({ type:'OPEN_SIDEPANEL' });
$('#workflowSelect').onchange = () => BF.setActiveWorkflow($('#workflowSelect').value);
$('#run').onclick = async () => { const workflow = workflows.find(w=>w.id===$('#workflowSelect').value); $('#status').textContent='Futtatás...'; const [tab] = await chrome.tabs.query({active:true,currentWindow:true}); const res = await chrome.tabs.sendMessage(tab.id, { type:'BF_RUN_WORKFLOW', workflow }); $('#status').textContent = res?.ok ? 'Kész.' : `Hiba: ${res?.error || 'ismeretlen'}`; };
init();
