const EXT_PREFIX = chrome.runtime.getURL('');

async function setLastActiveTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab && tab.url && !tab.url.startsWith(EXT_PREFIX) && /^https?:|^file:/.test(tab.url)) {
      await chrome.storage.local.set({ lastActiveTabId: tabId, lastActiveTabUrl: tab.url });
    }
  } catch (_) {}
}

chrome.runtime.onInstalled.addListener(async () => {
  if (chrome.sidePanel?.setPanelBehavior) {
    await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
  }
});

chrome.tabs.onActivated.addListener(info => setLastActiveTab(info.tabId));
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.active) setLastActiveTab(tabId);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.type === 'OPEN_BUILDER') {
      await chrome.tabs.create({ url: chrome.runtime.getURL('builder.html') });
      sendResponse({ ok: true });
      return;
    }
    if (msg?.type === 'OPEN_SIDEPANEL') {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (chrome.sidePanel?.open && tab?.windowId) {
        await chrome.sidePanel.open({ windowId: tab.windowId });
      }
      sendResponse({ ok: true });
      return;
    }
    if (msg?.type === 'GET_TARGET_TAB') {
      const { lastActiveTabId, lastActiveTabUrl } = await chrome.storage.local.get(['lastActiveTabId', 'lastActiveTabUrl']);
      let tabId = lastActiveTabId;
      let url = lastActiveTabUrl;
      try {
        const tab = tabId ? await chrome.tabs.get(tabId) : null;
        if (!tab || !tab.url || tab.url.startsWith(EXT_PREFIX)) throw new Error('bad tab');
        url = tab.url;
      } catch (_) {
        const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
        const tab = tabs.find(t => t.url && !t.url.startsWith(EXT_PREFIX));
        tabId = tab?.id;
        url = tab?.url;
      }
      sendResponse({ ok: Boolean(tabId), tabId, url });
      return;
    }
    if (msg?.type === 'SEND_TO_TARGET_TAB') {
      const { lastActiveTabId } = await chrome.storage.local.get('lastActiveTabId');
      const tabId = msg.tabId || lastActiveTabId;
      if (!tabId) throw new Error('Nincs aktív weboldal tab kiválasztva.');
      const response = await chrome.tabs.sendMessage(tabId, msg.payload);
      sendResponse({ ok: true, response });
      return;
    }
    if (msg?.type === 'OPEN_MAILTO') {
      await chrome.tabs.create({ url: msg.url });
      sendResponse({ ok: true });
      return;
    }
  })().catch(err => sendResponse({ ok: false, error: String(err.message || err) }));
  return true;
});
