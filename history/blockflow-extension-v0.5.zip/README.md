# BlockFlow v0.4

Javítások: valódi Chrome side panel külön tab fallback nélkül; builderből indított elemkiválasztáskor automatikus visszaváltás a cél weboldalra; erősebb hover-highlight; kattintáskor a ténylegesen kiemelt elem mentése.

# BlockFlow Automation MVP 0.3

Lokális, AI nélküli Chrome extension blokkos böngésző-automatizáláshoz.

## Fő javítások a 0.3-ban

- Automatikus content script injektálás futtatás, sidebar és elemkiválasztás előtt.
  - Nem kell újratölteni a weboldalt extension frissítés után.
  - Ez javítja az elemkiválasztást, kattintást, kitöltést, dry-runt és workflow futtatást.
- Sidebar megnyitás fallback.
  - Ha a Chrome sidePanel API nem nyílik meg, a sidebar külön extension tabon nyílik meg.
- Popupból/popuphoz küldött futtatás is ugyanazt a megbízható cél-tab logikát használja.
- Elemkiválasztásnál erősebb kattintásfogás: a weboldal saját click handlere nem nyeli el a picker kattintást.
- Selector attribútumkezelés javítva speciális karaktereknél.
- If / Repeat blokkok futtatása továbbra is MVP modellben működik:
  - `Ha...`: hamis feltételnél átugorja a következő N blokkot.
  - `Ismételd...`: az utána következő N blokkot ismétli X alkalommal.

## Telepítés

1. Csomagold ki a ZIP-et.
2. Chrome: `chrome://extensions`
3. Kapcsold be a `Developer mode` kapcsolót.
4. Kattints: `Load unpacked`.
5. Válaszd ki a kicsomagolt `blockflow-extension-v0.3` mappát.

## Fontos használati megjegyzések

- A legtöbb oldalhoz http/https tab szükséges.
- `chrome://`, Chrome Web Store és néhány böngésző belső oldal nem automatizálható.
- File URL-ekhez külön engedély kell: extension részletei -> `Allow access to file URLs`.
- Az extension nem küld emailt. Csak `mailto:` ablakot nyit, hosszú törzsnél vágólapra másol.

## Javasolt teszt

1. Nyiss meg egy normál weboldalt, például egy saját egyszerű HTML formot vagy bármely tesztoldalt.
2. Popup -> Builder megnyitása.
3. Adj hozzá `Adat kinyerése`, `Kattintás`, `Beillesztés / kitöltés` blokkokat.
4. A blokkoknál válaszd: `Elem kiválasztása az oldalról`.
5. Térj vissza az oldalra és kattints a cél elemre.
6. Futtasd előbb Dry-run módban.

## Jelenlegi MVP korlátok

- A Scratch-szerű felület még kártyás blokklista, nem teljes snap-canvas.
- A `Ha...` és `Ismételd...` blokkok nem tartalmaznak még vizuális gyermekblokkokat; a következő N blokkra hatnak.
- A popup detektálás általános heurisztikával működik, nem minden weboldali modal szerkezetet ismer fel tökéletesen.


## v0.5 javitas

- A side panel megnyitasat a popup gomb kozvetlen felhasznaloi kattintasabol vegzi.
- A service worker mar nem hivja kozvetetten a chrome.sidePanel.open() fuggvenyt, mert azt a Chrome elutasitja user gesture nelkul.
- Nincs kulon ablak/tab fallback. Ha nem nyithato side panel, hibauzenetet kapsz.
