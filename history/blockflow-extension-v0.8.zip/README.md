# BlockFlow Automation MVP 0.8

Lokális Chrome extension vizuális, blokkos weboldal-automatizáláshoz.

## Fő funkciók

- Manifest V3 Chrome extension
- Popup gyorsindító
- Valódi Chrome Side Panel
- Builder külön Chrome popup ablakban
- Blokkos workflow szerkesztés
- Elem kiválasztása az oldalról hover kerettel
- Import / export JSON formátumban
- Dry-run futtatás
- Futtatás előtti validáció
- Futási napló és hibás blokk kiemelése
- Élő változópanel futás után
- If blokk külön `HA IGAZ` és `KÜLÖNBEN` behúzott ágakkal
- Repeat blokk behúzott gyermekblokkokkal
- Automatikus watcher-trigger workflow indítással
- Egyszerű táblázat/lista sorfeldolgozó blokk
- Egyszerű email sablonkönyvtár
- Verzióelőzmény / visszaállítás mentésekből
- Email előkészítés `mailto:` linkkel, küldés nélkül
- Hosszú email törzs automatikus vágólapra másolása

## Telepítés

1. Csomagold ki a ZIP-et.
2. Chrome: `chrome://extensions`
3. Kapcsold be a Developer mode-ot.
4. Kattints: Load unpacked.
5. Válaszd ki a kicsomagolt mappát.

## Fontos

Az extension nem küld emailt, nem használ AI-t, és lokálisan működik.
A watcherek csak olyan oldalon futnak, ahol a content script aktív, vagyis normál weboldalakon, nyitott tabban.
