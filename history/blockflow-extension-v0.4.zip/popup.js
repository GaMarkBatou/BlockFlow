let workflows = [];
const $ = s => document.querySelector(s);

async function init(){
  const store = await BF.getStore();
  workflows = store.workflows;
  $('#workflowSelect').innerHTML = workflows.map(w=>`<option value="${w.id}" ${w.id===store.activeWorkflowId?'selected':''}>${w.name}${w.verified===false?' · nem ellenőrzött':''}</option>`).join('');
}

$('#openBuilder').onclick = () => chrome.runtime.sendMessage({ type:'OPEN_BUILDER' });
$('#openSide').onclick = async () => {
  const res = await chrome.runtime.sendMessage({ type:'OPEN_SIDEPANEL' });
  if (!res?.ok) $('#status').textContent = `Sidebar hiba: ${res?.error || 'ismeretlen hiba'}`;
  else if (res.mode === 'tabFallback') $('#status').textContent = 'A Chrome side panel nem nyílt meg, ezért külön tabon nyitottam meg.';
};
$('#workflowSelect').onchange = () => BF.setActiveWorkflow($('#workflowSelect').value);
$('#run').onclick = async () => {
  const workflow = workflows.find(w=>w.id===$('#workflowSelect').value);
  if (!workflow) return;
  if (workflow.verified === false && !confirm('Ez importált vagy nem ellenőrzött automatizmus. Javasolt előbb Dry-run módban tesztelni. Mégis futtatod?')) return;
  $('#status').textContent='Futtatás...';
  const res = await BF.sendToTarget({ type:'BF_RUN_WORKFLOW', workflow, options: { dryRun: false } });
  $('#status').textContent = res?.response?.ok ? 'Kész.' : `Hiba: ${res?.response?.error || res?.error || 'ismeretlen'}`;
};
init();
