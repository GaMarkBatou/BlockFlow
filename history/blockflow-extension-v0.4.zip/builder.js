let workflows = [];
let activeWorkflow = null;
let selectedBlockId = null;
let targetTabId = null;

const $ = sel => document.querySelector(sel);

async function init() {
  const store = await BF.getStore();
  workflows = store.workflows;
  activeWorkflow = workflows.find(w => w.id === store.activeWorkflowId) || workflows[0];
  selectedBlockId = activeWorkflow.blocks[0]?.id;
  await refreshTarget();
  renderAll();
}

async function refreshTarget() {
  const res = await BF.getTargetTab();
  targetTabId = res.tabId;
  $('#targetInfo').textContent = res.ok ? `Cél tab: ${safeHost(res.url)}` : 'Nincs weboldal cél tab';
}

function renderAll() { renderWorkflowList(); renderPalette(); renderBlocks(); renderInspector(); renderVariables(); renderImportWarning(); }

function renderImportWarning() {
  const warn = $('#importWarning');
  if (activeWorkflow?.verified === false || activeWorkflow?.imported) {
    warn.classList.remove('hidden');
    warn.textContent = 'Importált vagy még nem ellenőrzött automatizmus. Futtatás előtt használd a Dry-run módot és ellenőrizd az elemeket.';
  } else {
    warn.classList.add('hidden');
  }
}

function renderWorkflowList() {
  $('#workflowList').innerHTML = workflows.map(w => `<div class="list-item ${w.id===activeWorkflow.id?'selected':''}">
    <div class="list-title">${escapeHtml(w.name)}</div>
    <div class="muted">${w.blocks.length} blokk ${w.imported?' · importált':''} ${w.verified===false?' · nem ellenőrzött':''}</div>
    <div class="split" style="margin-top:8px"><button class="small" data-open="${w.id}">Megnyitás</button><button class="small danger" data-delwf="${w.id}">Törlés</button></div>
  </div>`).join('');
  document.querySelectorAll('[data-open]').forEach(b => b.onclick = async () => { await saveCurrent(); activeWorkflow = workflows.find(w => w.id === b.dataset.open); selectedBlockId = activeWorkflow.blocks[0]?.id; await BF.setActiveWorkflow(activeWorkflow.id); renderAll(); });
  document.querySelectorAll('[data-delwf]').forEach(b => b.onclick = async () => {
    if (workflows.length < 2) return alert('Legalább egy automatizmusnak maradnia kell.');
    if (!confirm('Törlöd ezt az automatizmust?')) return;
    workflows = workflows.filter(w => w.id !== b.dataset.delwf);
    activeWorkflow = workflows[0]; selectedBlockId = activeWorkflow.blocks[0]?.id;
    await chrome.storage.local.set({ workflows, activeWorkflowId: activeWorkflow.id }); renderAll();
  });
}

function renderPalette() {
  const grouped = {};
  BF.PALETTE.forEach(p => (grouped[p.cat] ||= []).push(p));
  $('#palette').innerHTML = Object.entries(grouped).map(([cat, items]) => `<div class="section-title">${cat}</div>` + items.map(item => `<button class="palette-btn" data-add="${item.type}"><span>${BF.BLOCKS[item.type].name}</span><span>+</span></button>`).join('')).join('');
  document.querySelectorAll('[data-add]').forEach(b => b.onclick = () => addBlock(b.dataset.add));
}

function addBlock(type) {
  if (type === 'trigger' && activeWorkflow.blocks.some(b => b.type === 'trigger')) return alert('Egy manuális indító blokk már van a workflow tetején.');
  const block = BF.newBlock(type);
  activeWorkflow.blocks.push(block);
  selectedBlockId = block.id;
  renderAll();
}

function renderBlocks() {
  $('#workflowName').value = activeWorkflow.name;
  const html = activeWorkflow.blocks.map((b, idx) => `<div class="block block-${b.type} ${b.id===selectedBlockId?'selected':''}" draggable="true" data-block="${b.id}">
    <div class="block-actions">
      <button class="small" data-up="${b.id}">↑</button><button class="small" data-down="${b.id}">↓</button>${b.type!=='trigger'?`<button class="small danger" data-del="${b.id}">×</button>`:''}
    </div>
    <div class="row"><span class="pill">${idx+1}</span><span class="block-title">${escapeHtml(BF.blockTitle(b))}</span></div>
    <div class="block-desc">${escapeHtml(BF.blockDesc(b))}</div>
  </div>`).join('');
  $('#blocks').innerHTML = html || '<div class="empty">Adj hozzá blokkokat a bal oldali palettából.</div>';
  document.querySelectorAll('[data-block]').forEach(el => {
    el.onclick = e => { if (e.target.tagName !== 'BUTTON') { selectedBlockId = el.dataset.block; renderAll(); }};
    el.ondragstart = e => e.dataTransfer.setData('text/plain', el.dataset.block);
    el.ondragover = e => e.preventDefault();
    el.ondrop = e => { e.preventDefault(); moveBlock(e.dataTransfer.getData('text/plain'), el.dataset.block); };
  });
  document.querySelectorAll('[data-up]').forEach(b => b.onclick = e => { e.stopPropagation(); reorder(b.dataset.up, -1); });
  document.querySelectorAll('[data-down]').forEach(b => b.onclick = e => { e.stopPropagation(); reorder(b.dataset.down, 1); });
  document.querySelectorAll('[data-del]').forEach(b => b.onclick = e => { e.stopPropagation(); activeWorkflow.blocks = activeWorkflow.blocks.filter(x => x.id !== b.dataset.del); selectedBlockId = activeWorkflow.blocks[0]?.id; renderAll(); });
}

function moveBlock(id, beforeId) {
  if (id === beforeId) return;
  const item = activeWorkflow.blocks.find(b => b.id === id);
  activeWorkflow.blocks = activeWorkflow.blocks.filter(b => b.id !== id);
  const idx = activeWorkflow.blocks.findIndex(b => b.id === beforeId);
  activeWorkflow.blocks.splice(idx, 0, item);
  renderAll();
}
function reorder(id, dir) { const i = activeWorkflow.blocks.findIndex(b => b.id === id); const j = i + dir; if (j < 0 || j >= activeWorkflow.blocks.length) return; [activeWorkflow.blocks[i], activeWorkflow.blocks[j]] = [activeWorkflow.blocks[j], activeWorkflow.blocks[i]]; renderAll(); }

function renderInspector() {
  const b = activeWorkflow.blocks.find(x => x.id === selectedBlockId);
  if (!b) { $('#inspector').innerHTML = '<div class="empty">Válassz blokkot.</div>'; return; }
  let html = `<div class="list-title">${escapeHtml(BF.BLOCKS[b.type]?.name || b.type)}</div>`;
  if (['click','fill','extract','watchElement'].includes(b.type)) html += targetEditor(b);
  if (b.type === 'click') html += checkboxField('confirmRisky','Kockázatos kattintásnál kérjen megerősítést', b.confirmRisky !== false) + numberField('timeoutMs','Max várakozás ms', b.timeoutMs || 5000);
  if (b.type === 'fill') html += valueSourceHelp() + textArea('value','Mit illesszen be?', b.value || '') + numberField('timeoutMs','Max várakozás ms', b.timeoutMs || 5000);
  if (b.type === 'extract') html += selectField('extractMode','Mit nyerjen ki?', b.extractMode || 'text', [['text','Látható szöveg'],['value','Mezőérték']]) + textField('varName','Változó neve', b.varName || 'adat') + numberField('timeoutMs','Max várakozás ms', b.timeoutMs || 5000);
  if (b.type === 'watchText') html += textField('text','Figyelt szöveg vagy karakter', b.text || '') + numberField('timeoutMs','Timeout ms', b.timeoutMs || 30000) + checkboxField('caseSensitive','Kis/nagybetű számítson', Boolean(b.caseSensitive));
  if (b.type === 'watchElement') html += numberField('timeoutMs','Timeout ms', b.timeoutMs || 30000);
  if (b.type === 'wait') html += selectField('waitMode','Várakozás típusa', b.waitMode || 'time', [['time','Idő'],['text','Szöveg megjelenése'],['element','Elem megjelenése']]) + (b.waitMode === 'time' ? numberField('ms','Idő ms', b.ms || 1000) : b.waitMode === 'text' ? textField('text','Szöveg', b.text || '') + numberField('timeoutMs','Timeout ms', b.timeoutMs || 5000) : targetEditor(b) + numberField('timeoutMs','Timeout ms', b.timeoutMs || 5000));
  if (b.type === 'ifBlock') html += selectField('conditionMode','Feltétel', b.conditionMode || 'textExists', [['textExists','Szöveg létezik'],['elementExists','Elem létezik'],['valueContains','Elem értéke tartalmazza']]) + (b.conditionMode === 'elementExists' || b.conditionMode === 'valueContains' ? targetEditor(b) : '') + (b.conditionMode === 'valueContains' ? textField('value','Keresett érték', b.value || '') : b.conditionMode === 'textExists' ? textField('text','Keresett szöveg', b.text || '') : '') + numberField('skipCount','Ha hamis, ennyi következő blokkot ugorjon át', b.skipCount || 1) + numberField('timeoutMs','Elemkeresési timeout ms', b.timeoutMs || 1000);
  if (b.type === 'repeatBlock') html += numberField('repeatCount','Ismétlések száma', b.repeatCount || 2) + numberField('blockCount','Ennyi következő blokkot ismételjen', b.blockCount || 1) + `<div class="status">MVP logika: ez a blokk az utána következő blokkokat ismétli, majd átugrik az ismételt szakasz utánra.</div>`;
  if (b.type === 'popupWait') html += numberField('timeoutMs','Popup timeout ms', b.timeoutMs || 10000) + `<button id="testPopup" class="ghost">Popup tesztelése</button>`;
  if (b.type === 'popupExtract') html += selectField('extractMode','Mit nyerjen ki?', b.extractMode || 'text', [['text','Teljes popup szöveg'],['title','Popup cím']]) + textField('varName','Változó neve', b.varName || 'popup_szoveg');
  if (b.type === 'popupClick') html += textField('buttonText','Popup gomb szövege', b.buttonText || 'OK') + numberField('timeoutMs','Timeout ms', b.timeoutMs || 5000);
  if (b.type === 'copy') html += valueSourceHelp() + textArea('value','Mit másoljon?', b.value || '');
  if (b.type === 'email') html += textField('to','Címzett', b.to || '') + textField('subject','Tárgy', b.subject || '') + textArea('body','Törzs', b.body || '') + textField('resultName','Draft változó neve', b.resultName || 'email_draft');
  if (b.type === 'openEmail') html += textField('draftName','Email draft változó', b.draftName || 'email_draft') + numberField('maxUrlLength','Mailto max hossz', b.maxUrlLength || 1800) + `<div class="status">Az extension nem küld emailt. Csak mailto ablakot nyit; hosszú törzs esetén vágólapra másol.</div>`;
  html += `<div class="hr"></div><button id="testBlock" class="ghost">Blokk tesztelése</button>`;
  $('#inspector').innerHTML = html;
  $('#inspector').querySelectorAll('[data-field]').forEach(input => {
    const handler = () => updateField(input.dataset.field, input.type === 'checkbox' ? input.checked : input.value);
    input.oninput = handler; input.onchange = handler;
  });
  const pick = $('#pickElement'); if (pick) pick.onclick = () => startPick(b.id, 'target');
  const test = $('#testBlock'); if (test) test.onclick = () => testBlock(b);
  const popupTest = $('#testPopup'); if (popupTest) popupTest.onclick = testPopup;
}
function targetEditor(b){ return `<div class="field"><label>Cél elem</label><div class="status">${b.target ? escapeHtml(b.target.label + ' · ' + b.target.tag) : 'Nincs elem kiválasztva'}</div><button id="pickElement" class="primary">Elem kiválasztása az oldalról</button></div>`; }
function valueSourceHelp(){ return `<div class="status">Használható változók: {{email}}, {{nev}}, {{popup_szoveg}}. A jobb oldali változóra kattintva vágólapra másolódik.</div>`; }
function textField(field,label,value){ return `<div class="field"><label>${label}</label><input data-field="${field}" value="${escapeAttr(value)}"></div>`; }
function numberField(field,label,value){ return `<div class="field"><label>${label}</label><input data-field="${field}" type="number" value="${escapeAttr(value)}"></div>`; }
function checkboxField(field,label,value){ return `<label class="check"><input data-field="${field}" type="checkbox" ${value?'checked':''}> ${label}</label>`; }
function textArea(field,label,value){ return `<div class="field"><label>${label}</label><textarea data-field="${field}">${escapeHtml(value)}</textarea></div>`; }
function selectField(field,label,value,options){ return `<div class="field"><label>${label}</label><select data-field="${field}">${options.map(([v,l])=>`<option value="${v}" ${v===value?'selected':''}>${l}</option>`).join('')}</select></div>`; }
function updateField(field, value) { const b = activeWorkflow.blocks.find(x => x.id === selectedBlockId); if (!b) return; b[field] = ['timeoutMs','ms','maxUrlLength','skipCount','repeatCount','blockCount'].includes(field) ? Number(value) : value; activeWorkflow.verified = activeWorkflow.imported ? false : activeWorkflow.verified; renderBlocks(); renderVariables(); renderImportWarning(); if (['waitMode','conditionMode'].includes(field)) renderInspector(); }

function renderVariables() {
  $('#variables').innerHTML = BF.collectVariables(activeWorkflow).map(v => `<span class="var-chip" data-var="${v}">{{${v}}}</span>`).join('');
  document.querySelectorAll('[data-var]').forEach(chip => chip.onclick = async () => { await navigator.clipboard.writeText(`{{${chip.dataset.var}}}`); $('#log').textContent = `Változó vágólapra másolva: {{${chip.dataset.var}}}`; });
}

async function startPick(blockId, field) {
  await refreshTarget();
  const res = await BF.sendToTarget({ type: 'BF_START_PICKER', context: { source: 'builder', workflowId: activeWorkflow.id, blockId, field } }, targetTabId);
  if (!res.ok) alert(res.error || 'Nem sikerült elindítani az elemkiválasztást.');
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'BF_ELEMENT_PICKED' && msg.context?.source === 'builder') {
    const b = activeWorkflow.blocks.find(x => x.id === msg.context.blockId);
    if (b) { b[msg.context.field || 'target'] = msg.element; selectedBlockId = b.id; renderAll(); $('#log').textContent = `Elem kiválasztva: ${msg.element.label}`; }
  }
});

async function testBlock(b) {
  await refreshTarget();
  if (b.target) {
    const res = await BF.sendToTarget({ type: 'BF_TEST_TARGET', target: b.target }, targetTabId);
    $('#log').textContent = res.response?.ok ? `Teszt OK: ${res.response.element.label}` : `Teszt hiba: elem nem található`;
  } else if (b.type === 'popupWait' || b.type === 'popupExtract' || b.type === 'popupClick') {
    await testPopup();
  } else $('#log').textContent = 'Ehhez a blokkhoz nincs külön cél elem. Használd a Dry-run futtatást.';
}
async function testPopup() { await refreshTarget(); const res = await BF.sendToTarget({ type: 'BF_TEST_POPUP' }, targetTabId); $('#log').textContent = res.response?.ok ? `Popup találva:\n${res.response.text}` : `Nem találtam popupot.`; }

async function saveCurrent(){ activeWorkflow.name = $('#workflowName').value || 'Névtelen automatizmus'; workflows = workflows.map(w => w.id === activeWorkflow.id ? activeWorkflow : w); await BF.saveWorkflow(activeWorkflow); const store = await BF.getStore(); workflows = store.workflows; }
async function runCurrent(dryRun=false) {
  await saveCurrent(); await refreshTarget();
  if (!dryRun && (activeWorkflow.verified === false || activeWorkflow.imported)) {
    if (!confirm('Ez importált vagy nem ellenőrzött automatizmus. Javasolt előbb Dry-run módban tesztelni. Mégis futtatod?')) return;
  }
  $('#log').textContent = dryRun ? 'Dry-run futtatás...' : 'Futtatás...';
  const res = await BF.sendToTarget({ type: 'BF_RUN_WORKFLOW', workflow: activeWorkflow, options: { dryRun } }, targetTabId);
  $('#log').textContent = res.response?.ok ? `Kész.${dryRun?' [dry-run]':''}\n${JSON.stringify(res.response.result.vars, null, 2)}\n\n${(res.response.result.log || []).join('\n')}` : `Hiba: ${res.response?.error || res.error}`;
}

$('#workflowName').oninput = () => { activeWorkflow.name = $('#workflowName').value; renderWorkflowList(); };
$('#saveWorkflow').onclick = async () => { await saveCurrent(); $('#log').textContent = 'Mentve.'; renderAll(); };
$('#newWorkflow').onclick = async () => { await saveCurrent(); const w = BF.DEFAULT_WORKFLOW(); workflows.push(w); activeWorkflow = w; selectedBlockId = w.blocks[0].id; await BF.saveWorkflow(w); renderAll(); };
$('#duplicateWorkflow').onclick = async () => { const w = JSON.parse(JSON.stringify(activeWorkflow)); w.id = crypto.randomUUID(); w.name += ' másolat'; w.imported = false; w.verified = true; w.blocks.forEach(b => b.id = crypto.randomUUID()); workflows.push(w); activeWorkflow = w; selectedBlockId = w.blocks[0]?.id; await BF.saveWorkflow(w); renderAll(); };
$('#markVerified').onclick = async () => { activeWorkflow.verified = true; activeWorkflow.imported = false; await saveCurrent(); renderAll(); $('#log').textContent = 'Automatizmus ellenőrzöttként jelölve.'; };
$('#runWorkflow').onclick = () => runCurrent(false);
$('#dryRunWorkflow').onclick = () => runCurrent(true);
$('#stopRun').onclick = async () => { const res = await BF.sendToTarget({ type: 'BF_STOP_RUN' }, targetTabId); $('#log').textContent = res.ok ? 'Stop kérés elküldve.' : (res.error || 'Stop hiba.'); };
$('#exportOne').onclick = () => BF.downloadJson(`${safeFile(activeWorkflow.name)}.json`, BF.exportPayload([activeWorkflow]));
$('#exportAll').onclick = () => BF.downloadJson(`blockflow-backup.json`, BF.exportPayload(workflows));
$('#importBtn').onclick = () => $('#importFile').click();
$('#importFile').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  try {
    const payload = JSON.parse(await f.text());
    const analysis = BF.analyzeImport(payload);
    $('#importPreview').textContent = `Import előnézet:\nSéma: ${analysis.schemaVersion}\nWorkflow-k: ${analysis.rawCount}\n\n` + analysis.workflows.map(w => `- ${w.name}: ${w.blockCount} blokk, ${w.riskyCount} kockázatos/módosító blokk\n  Típusok: ${w.blocks.join(', ')}`).join('\n');
    if (!confirm(`${analysis.rawCount} workflow importálható. Importálod?`)) return;
    const imported = await BF.importPayload(payload);
    const store = await BF.getStore(); workflows = store.workflows; activeWorkflow = workflows.find(w => w.id === store.activeWorkflowId); selectedBlockId = activeWorkflow.blocks[0]?.id; renderAll(); $('#log').textContent = `${imported.length} workflow importálva. Első futtatás előtt Dry-run javasolt.`;
  } catch(err) { alert(err.message); } finally { e.target.value=''; }
};

function escapeHtml(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function escapeAttr(s){return escapeHtml(s).replace(/'/g,'&#39;');}
function safeFile(s){return String(s||'automation').toLowerCase().replace(/[^a-z0-9_-]+/g,'-').replace(/^-|-$/g,'') || 'automation';}
function safeHost(url){ try { return new URL(url).hostname; } catch { return url || 'ismeretlen'; } }

init();
