const EXT_PREFIX = chrome.runtime.getURL('');
const INJECTABLE_URL_RE = /^(https?:|file:)/;

async function setLastActiveTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab && tab.url && !tab.url.startsWith(EXT_PREFIX) && INJECTABLE_URL_RE.test(tab.url)) {
      await chrome.storage.local.set({ lastActiveTabId: tabId, lastActiveTabUrl: tab.url });
    }
  } catch (_) {}
}

async function getUsableTargetTab(preferredTabId) {
  if (preferredTabId) {
    try {
      const tab = await chrome.tabs.get(preferredTabId);
      if (tab?.id && tab.url && !tab.url.startsWith(EXT_PREFIX) && INJECTABLE_URL_RE.test(tab.url)) return tab;
    } catch (_) {}
  }

  // Prefer the currently active real web page. This matters when the user opens
  // the builder from a page and immediately starts picking an element: stale
  // lastActiveTabId values must not steal the target.
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const activeWebTab = tabs.find(t => t?.id && t.url && !t.url.startsWith(EXT_PREFIX) && INJECTABLE_URL_RE.test(t.url));
  if (activeWebTab) return activeWebTab;

  const { lastActiveTabId } = await chrome.storage.local.get('lastActiveTabId');
  if (lastActiveTabId) {
    try {
      const tab = await chrome.tabs.get(lastActiveTabId);
      if (tab?.id && tab.url && !tab.url.startsWith(EXT_PREFIX) && INJECTABLE_URL_RE.test(tab.url)) return tab;
    } catch (_) {}
  }

  const allTabs = await chrome.tabs.query({ currentWindow: true });
  return allTabs.find(t => t?.id && t.url && !t.url.startsWith(EXT_PREFIX) && INJECTABLE_URL_RE.test(t.url));
}
async function ensureContentScript(tabId) {
  let pinged = false;
  try {
    const ping = await chrome.tabs.sendMessage(tabId, { type: 'BF_PING' });
    pinged = Boolean(ping?.ok);
  } catch (_) {}
  if (pinged) return;

  await chrome.scripting.insertCSS({ target: { tabId }, files: ['contentScript.css'] }).catch(() => {});
  await chrome.scripting.executeScript({ target: { tabId }, files: ['contentScript.js'] });

  // Give the content script one small tick to register its message listener.
  await new Promise(resolve => setTimeout(resolve, 25));
}

chrome.runtime.onInstalled.addListener(async () => {
  if (chrome.sidePanel?.setPanelBehavior) {
    try { await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false }); } catch (_) {}
  }
});

chrome.tabs.onActivated.addListener(info => setLastActiveTab(info.tabId));
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.active) setLastActiveTab(tabId);
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.type === 'OPEN_BUILDER') {
      const target = await getUsableTargetTab(sender?.tab?.id);
      if (target?.id) await setLastActiveTab(target.id);
      await chrome.tabs.create({ url: chrome.runtime.getURL('builder.html') });
      sendResponse({ ok: true, targetTabId: target?.id });
      return;
    }

    if (msg?.type === 'OPEN_SIDEPANEL') {
      const target = await getUsableTargetTab(sender?.tab?.id);
      if (!target?.id) throw new Error('Nincs használható weboldal tab a sidebarhoz.');
      await setLastActiveTab(target.id);
      if (!chrome.sidePanel?.open) throw new Error('A Chrome sidePanel API nem elérhető ebben a böngészőben. Friss Chrome szükséges.');
      if (chrome.sidePanel?.setOptions) {
        await chrome.sidePanel.setOptions({ tabId: target.id, path: 'sidepanel.html', enabled: true });
      }
      // Use tabId instead of windowId so it opens as the page side panel, not a separate extension page.
      await chrome.sidePanel.open({ tabId: target.id });
      sendResponse({ ok: true, mode: 'sidePanel', tabId: target.id });
      return;
    }

    if (msg?.type === 'GET_TARGET_TAB') {
      const target = await getUsableTargetTab(msg.tabId);
      if (target?.id) await setLastActiveTab(target.id);
      sendResponse({ ok: Boolean(target?.id), tabId: target?.id, url: target?.url });
      return;
    }

    if (msg?.type === 'SEND_TO_TARGET_TAB') {
      const target = await getUsableTargetTab(msg.tabId);
      if (!target?.id) throw new Error('Nincs használható aktív weboldal tab. Nyiss meg egy http/https oldalt, majd próbáld újra.');
      await setLastActiveTab(target.id);
      await ensureContentScript(target.id);
      const response = await chrome.tabs.sendMessage(target.id, msg.payload);
      if (msg.payload?.type === 'BF_START_PICKER' && msg.payload?.context?.source === 'builder') {
        try { await chrome.windows.update(target.windowId, { focused: true }); } catch (_) {}
        try { await chrome.tabs.update(target.id, { active: true }); } catch (_) {}
      }
      sendResponse({ ok: true, response, tabId: target.id, url: target.url });
      return;
    }

    if (msg?.type === 'OPEN_MAILTO') {
      await chrome.tabs.create({ url: msg.url });
      sendResponse({ ok: true });
      return;
    }
  })().catch(err => sendResponse({ ok: false, error: String(err.message || err) }));
  return true;
});
