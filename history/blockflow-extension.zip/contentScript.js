(() => {
  if (window.__blockFlowLoaded) return;
  window.__blockFlowLoaded = true;

  let picker = null;
  let stopRequested = false;

  function cssPath(el) {
    if (!el || el.nodeType !== 1) return '';
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let node = el;
    while (node && node.nodeType === 1 && parts.length < 5) {
      let part = node.tagName.toLowerCase();
      if (node.classList.length) part += '.' + [...node.classList].slice(0, 3).map(c => CSS.escape(c)).join('.');
      const parent = node.parentElement;
      if (parent) {
        const siblings = [...parent.children].filter(x => x.tagName === node.tagName);
        if (siblings.length > 1) part += `:nth-of-type(${siblings.indexOf(node) + 1})`;
      }
      parts.unshift(part);
      node = parent;
    }
    return parts.join(' > ');
  }

  function labelFor(el) {
    if (!el) return '';
    if (el.id) {
      const label = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (label) return label.innerText.trim();
    }
    const wrapping = el.closest('label');
    if (wrapping) return wrapping.innerText.trim();
    const nearby = el.parentElement?.innerText?.trim();
    return nearby ? nearby.slice(0, 120) : '';
  }

  function descriptor(el) {
    const rect = el.getBoundingClientRect();
    const text = (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('placeholder') || '').trim();
    return {
      label: labelFor(el) || text.slice(0, 80) || el.name || el.id || el.tagName.toLowerCase(),
      tag: el.tagName.toLowerCase(),
      type: el.getAttribute('type') || '',
      id: el.id || '',
      name: el.getAttribute('name') || '',
      role: el.getAttribute('role') || '',
      ariaLabel: el.getAttribute('aria-label') || '',
      placeholder: el.getAttribute('placeholder') || '',
      text: text.slice(0, 180),
      href: el.getAttribute('href') || '',
      css: cssPath(el),
      rect: { x: Math.round(rect.x), y: Math.round(rect.y), width: Math.round(rect.width), height: Math.round(rect.height) }
    };
  }

  function candidatesFor(d) {
    const out = [];
    if (!d) return out;
    if (d.id) out.push(`#${CSS.escape(d.id)}`);
    if (d.name) out.push(`${d.tag || ''}[name="${CSS.escape(d.name)}"]`);
    if (d.ariaLabel) out.push(`${d.tag || ''}[aria-label="${CSS.escape(d.ariaLabel)}"]`);
    if (d.placeholder) out.push(`${d.tag || ''}[placeholder="${CSS.escape(d.placeholder)}"]`);
    if (d.css) out.push(d.css);
    return out.filter(Boolean);
  }

  function findElement(target) {
    for (const selector of candidatesFor(target)) {
      try {
        const el = document.querySelector(selector);
        if (el) return el;
      } catch (_) {}
    }
    if (target?.text) {
      const all = [...document.querySelectorAll('button,a,input,textarea,select,[role="button"],div,span')];
      const text = target.text.trim().slice(0, 80).toLowerCase();
      const el = all.find(x => ((x.innerText || x.value || '').trim().toLowerCase()).includes(text));
      if (el) return el;
    }
    return null;
  }

  function showBadge(text) {
    removeBadge();
    const badge = document.createElement('div');
    badge.className = 'bf-picker-badge';
    badge.dataset.bfBadge = '1';
    badge.textContent = text;
    document.documentElement.appendChild(badge);
  }
  function removeBadge() {
    document.querySelectorAll('[data-bf-badge="1"]').forEach(x => x.remove());
  }

  function startPicker(context) {
    stopPicker();
    showBadge('BlockFlow elemkiválasztás aktív. Kattints egy elemre. ESC: megszakítás.');
    picker = { hovered: null, context };
    const over = ev => {
      const el = ev.target;
      if (!el || el === document.documentElement || el === document.body || el.dataset?.bfBadge) return;
      if (picker.hovered) picker.hovered.classList.remove('bf-hover-outline');
      picker.hovered = el;
      el.classList.add('bf-hover-outline');
    };
    const click = ev => {
      ev.preventDefault(); ev.stopPropagation();
      const picked = descriptor(ev.target);
      stopPicker();
      chrome.runtime.sendMessage({ type: 'BF_ELEMENT_PICKED', context, element: picked });
    };
    const key = ev => { if (ev.key === 'Escape') stopPicker(); };
    picker.listeners = { over, click, key };
    document.addEventListener('mouseover', over, true);
    document.addEventListener('click', click, true);
    document.addEventListener('keydown', key, true);
  }

  function stopPicker() {
    if (!picker) return;
    if (picker.hovered) picker.hovered.classList.remove('bf-hover-outline');
    const { over, click, key } = picker.listeners || {};
    document.removeEventListener('mouseover', over, true);
    document.removeEventListener('click', click, true);
    document.removeEventListener('keydown', key, true);
    picker = null;
    removeBadge();
  }

  const sleep = ms => new Promise(r => setTimeout(r, ms));

  async function waitForElement(target, timeoutMs = 5000) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const el = findElement(target);
      if (el) return el;
      await sleep(150);
    }
    return null;
  }

  function interpolate(input, vars) {
    return String(input || '').replace(/{{\s*([\w.-]+)\s*}}/g, (_, key) => vars[key] ?? '');
  }

  function copyText(text) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.focus(); ta.select();
    try { document.execCommand('copy'); } finally { ta.remove(); }
  }

  async function runWorkflow(workflow) {
    stopRequested = false;
    const vars = {};
    const log = [];
    const blocks = workflow.blocks || [];
    for (let i = 0; i < blocks.length; i++) {
      if (stopRequested) throw new Error('Futtatás megszakítva.');
      const b = blocks[i];
      if (b.type === 'trigger') continue;
      log.push(`Lépés ${i + 1}: ${b.type}`);
      if (b.type === 'wait') {
        if (b.waitMode === 'element' && b.target) {
          const el = await waitForElement(b.target, Number(b.timeoutMs || 5000));
          if (!el) throw new Error(`Nem jelent meg az elem: ${b.target.label || b.target.css}`);
        } else if (b.waitMode === 'text') {
          const needle = interpolate(b.text || '', vars);
          const start = Date.now();
          while (Date.now() - start < Number(b.timeoutMs || 5000)) {
            if (document.body.innerText.includes(needle)) break;
            await sleep(150);
          }
        } else {
          await sleep(Number(b.ms || 1000));
        }
      }
      if (b.type === 'click') {
        const el = await waitForElement(b.target, Number(b.timeoutMs || 5000));
        if (!el) throw new Error(`Nem található kattintási cél: ${b.target?.label || 'nincs megadva'}`);
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        el.classList.add('bf-run-outline');
        await sleep(120);
        el.click();
        setTimeout(() => el.classList.remove('bf-run-outline'), 700);
      }
      if (b.type === 'fill') {
        const el = await waitForElement(b.target, Number(b.timeoutMs || 5000));
        if (!el) throw new Error(`Nem található mező: ${b.target?.label || 'nincs megadva'}`);
        const value = interpolate(b.value || '', vars);
        el.scrollIntoView({ block: 'center', behavior: 'smooth' });
        el.focus();
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
      }
      if (b.type === 'extract') {
        const el = await waitForElement(b.target, Number(b.timeoutMs || 5000));
        if (!el) throw new Error(`Nem található kinyerendő elem: ${b.target?.label || 'nincs megadva'}`);
        const val = b.extractMode === 'value' ? (el.value || '') : ((el.innerText || el.textContent || el.value || '').trim());
        vars[b.varName || `valtozo_${i}`] = val;
      }
      if (b.type === 'copy') {
        copyText(interpolate(b.value || '', vars));
      }
      if (b.type === 'email') {
        vars[b.resultName || 'email_draft'] = {
          to: interpolate(b.to || '', vars),
          subject: interpolate(b.subject || '', vars),
          body: interpolate(b.body || '', vars)
        };
      }
      if (b.type === 'openEmail') {
        const draft = vars[b.draftName || 'email_draft'];
        if (!draft) throw new Error('Nincs email draft. Tegyél elé Email összeállítása blokkot.');
        const full = `mailto:${encodeURIComponent(draft.to)}?subject=${encodeURIComponent(draft.subject)}&body=${encodeURIComponent(draft.body)}`;
        if (full.length > Number(b.maxUrlLength || 1800)) {
          copyText(draft.body);
          const shortUrl = `mailto:${encodeURIComponent(draft.to)}?subject=${encodeURIComponent(draft.subject)}`;
          chrome.runtime.sendMessage({ type: 'OPEN_MAILTO', url: shortUrl });
          alert('Az email törzse túl hosszú volt a mailto linkhez, ezért vágólapra került. Illeszd be a megnyíló emailbe.');
        } else {
          chrome.runtime.sendMessage({ type: 'OPEN_MAILTO', url: full });
        }
      }
    }
    return { vars, log };
  }

  function pageSummary() {
    const elements = [...document.querySelectorAll('input,textarea,select,button,a,[role="button"]')].slice(0, 200).map(descriptor);
    return { title: document.title, url: location.href, elements };
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    (async () => {
      if (msg?.type === 'BF_START_PICKER') { startPicker(msg.context || {}); sendResponse({ ok: true }); return; }
      if (msg?.type === 'BF_STOP_PICKER') { stopPicker(); sendResponse({ ok: true }); return; }
      if (msg?.type === 'BF_PAGE_SUMMARY') { sendResponse({ ok: true, summary: pageSummary() }); return; }
      if (msg?.type === 'BF_TEST_TARGET') { const el = findElement(msg.target); sendResponse({ ok: Boolean(el), element: el ? descriptor(el) : null }); return; }
      if (msg?.type === 'BF_RUN_WORKFLOW') { const result = await runWorkflow(msg.workflow); sendResponse({ ok: true, result }); return; }
      if (msg?.type === 'BF_STOP_RUN') { stopRequested = true; sendResponse({ ok: true }); return; }
    })().catch(err => sendResponse({ ok: false, error: String(err.message || err) }));
    return true;
  });
})();
