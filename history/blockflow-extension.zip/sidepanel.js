let workflows = [], targetTabId = null;
const $ = s => document.querySelector(s);
async function init(){ await refreshTarget(); const store = await BF.getStore(); workflows=store.workflows; $('#workflowSelect').innerHTML = workflows.map(w=>`<option value="${w.id}" ${w.id===store.activeWorkflowId?'selected':''}>${w.name}</option>`).join(''); }
async function refreshTarget(){ const res = await BF.getTargetTab(); targetTabId = res.tabId; $('#target').textContent = res.ok ? res.url : 'Nincs aktív weboldal.'; }
$('#workflowSelect').onchange=()=>BF.setActiveWorkflow($('#workflowSelect').value);
$('#openBuilder').onclick=()=>chrome.runtime.sendMessage({type:'OPEN_BUILDER'});
$('#run').onclick=async()=>{ await refreshTarget(); const wf=workflows.find(w=>w.id===$('#workflowSelect').value); $('#log').textContent='Futtatás...'; const res=await BF.sendToTarget({type:'BF_RUN_WORKFLOW', workflow:wf}, targetTabId); $('#log').textContent=res.response?.ok ? `Kész.\n${JSON.stringify(res.response.result.vars,null,2)}` : `Hiba: ${res.response?.error || res.error}`; };
$('#stop').onclick=async()=>{ const res=await BF.sendToTarget({type:'BF_STOP_RUN'}, targetTabId); $('#log').textContent=res.ok?'Stop elküldve.':res.error; };
$('#scan').onclick=async()=>{ await refreshTarget(); const res=await BF.sendToTarget({type:'BF_PAGE_SUMMARY'}, targetTabId); const s=res.response?.summary; $('#log').textContent=s?`Cím: ${s.title}\nElemek: ${s.elements.length}`:`Hiba: ${res.response?.error || res.error}`; };
$('#pick').onclick=async()=>{ await refreshTarget(); const res=await BF.sendToTarget({type:'BF_START_PICKER', context:{source:'sidepanel'}}, targetTabId); $('#log').textContent=res.ok?'Kattints egy elemre az oldalon.':'Nem sikerült indítani.'; };
chrome.runtime.onMessage.addListener(msg=>{ if(msg?.type==='BF_ELEMENT_PICKED' && msg.context?.source==='sidepanel'){ $('#picked').textContent=JSON.stringify(msg.element,null,2); $('#log').textContent=`Elem kiválasztva: ${msg.element.label}`; }});
init();
