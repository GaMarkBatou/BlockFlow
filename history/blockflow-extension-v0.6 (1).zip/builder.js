let workflows = [];
let activeWorkflow = null;
let selectedBlockId = null;
let targetTabId = null;

const $ = sel => document.querySelector(sel);
const CONTAINERS = new Set(['ifBlock', 'repeatBlock']);

async function init() {
  const store = await BF.getStore();
  workflows = store.workflows;
  activeWorkflow = workflows.find(w => w.id === store.activeWorkflowId) || workflows[0];
  normalizeWorkflow(activeWorkflow);
  selectedBlockId = firstBlock(activeWorkflow.blocks)?.id;
  await refreshTarget();
  renderAll();
}

function normalizeWorkflow(workflow) {
  const walk = blocks => {
    for (let i = 0; i < (blocks || []).length; i++) {
      const b = blocks[i];
      if (CONTAINERS.has(b.type) && !Array.isArray(b.children)) b.children = [];

      // Automatikus migráció a régi v0.2-v0.5 lineáris modellből:
      // az if/repeat után következő N blokk bekerül vizuális gyermekblokknak.
      if (b.type === 'repeatBlock' && (!b.children || !b.children.length) && Number(b.blockCount || 0) > 0) {
        const n = Math.max(0, Math.min(50, Number(b.blockCount || 0)));
        b.children = blocks.splice(i + 1, n);
        delete b.blockCount;
      }
      if (b.type === 'ifBlock' && (!b.children || !b.children.length) && Number(b.skipCount || 0) > 0) {
        const n = Math.max(0, Math.min(50, Number(b.skipCount || 0)));
        b.children = blocks.splice(i + 1, n);
        delete b.skipCount;
      }
      if (Array.isArray(b.children)) walk(b.children);
    }
  };
  workflow.blocks ||= [];
  walk(workflow.blocks);
}

function firstBlock(blocks) {
  for (const b of blocks || []) return b;
  return null;
}

async function refreshTarget() {
  const res = await BF.getTargetTab();
  targetTabId = res.tabId;
  $('#targetInfo').textContent = res.ok ? `Cél tab: ${safeHost(res.url)}` : 'Nincs weboldal cél tab';
}

function renderAll() {
  normalizeWorkflow(activeWorkflow);
  renderWorkflowList();
  renderPalette();
  renderBlocks();
  renderInspector();
  renderVariables();
  renderImportWarning();
}

function renderImportWarning() {
  const warn = $('#importWarning');
  if (activeWorkflow?.verified === false || activeWorkflow?.imported) {
    warn.classList.remove('hidden');
    warn.textContent = 'Importált vagy még nem ellenőrzött automatizmus. Futtatás előtt használd a Dry-run módot és ellenőrizd az elemeket.';
  } else {
    warn.classList.add('hidden');
  }
}

function renderWorkflowList() {
  $('#workflowList').innerHTML = workflows.map(w => `<div class="list-item ${w.id===activeWorkflow.id?'selected':''}">
    <div class="list-title">${escapeHtml(w.name)}</div>
    <div class="muted">${BF.countBlocks ? BF.countBlocks(w.blocks) : (w.blocks||[]).length} blokk ${w.imported?' · importált':''} ${w.verified===false?' · nem ellenőrzött':''}</div>
    <div class="split" style="margin-top:8px"><button class="small" data-open="${w.id}">Megnyitás</button><button class="small danger" data-delwf="${w.id}">Törlés</button></div>
  </div>`).join('');
  document.querySelectorAll('[data-open]').forEach(b => b.onclick = async () => {
    await saveCurrent();
    activeWorkflow = workflows.find(w => w.id === b.dataset.open);
    normalizeWorkflow(activeWorkflow);
    selectedBlockId = firstBlock(activeWorkflow.blocks)?.id;
    await BF.setActiveWorkflow(activeWorkflow.id);
    renderAll();
  });
  document.querySelectorAll('[data-delwf]').forEach(b => b.onclick = async () => {
    if (workflows.length < 2) return alert('Legalább egy automatizmusnak maradnia kell.');
    if (!confirm('Törlöd ezt az automatizmust?')) return;
    workflows = workflows.filter(w => w.id !== b.dataset.delwf);
    activeWorkflow = workflows[0];
    normalizeWorkflow(activeWorkflow);
    selectedBlockId = firstBlock(activeWorkflow.blocks)?.id;
    await chrome.storage.local.set({ workflows, activeWorkflowId: activeWorkflow.id });
    renderAll();
  });
}

function renderPalette() {
  const selected = findBlock(selectedBlockId)?.block;
  const grouped = {};
  BF.PALETTE.forEach(p => (grouped[p.cat] ||= []).push(p));
  const hint = selected && CONTAINERS.has(selected.type)
    ? `<div class="status">Kiválasztott konténer: <b>${escapeHtml(BF.BLOCKS[selected.type].name)}</b>. Az új blokkok ide, behúzva kerülnek.</div>`
    : `<div class="status muted">Konténer kijelölésekor az új blokkok automatikusan alá kerülnek behúzva.</div>`;
  $('#palette').innerHTML = hint + Object.entries(grouped).map(([cat, items]) => `<div class="section-title">${cat}</div>` + items.map(item => `<button class="palette-btn" data-add="${item.type}"><span>${BF.BLOCKS[item.type].name}</span><span>+</span></button>`).join('')).join('');
  document.querySelectorAll('[data-add]').forEach(b => b.onclick = () => addBlock(b.dataset.add));
}

function addBlock(type) {
  if (type === 'trigger' && containsType(activeWorkflow.blocks, 'trigger')) return alert('Egy manuális indító blokk már van a workflow tetején.');
  const block = BF.newBlock(type);
  const selected = findBlock(selectedBlockId)?.block;
  if (selected && CONTAINERS.has(selected.type)) {
    selected.children ||= [];
    selected.children.push(block);
  } else {
    activeWorkflow.blocks.push(block);
  }
  selectedBlockId = block.id;
  markDirty();
  renderAll();
}

function containsType(blocks, type) {
  let found = false;
  walk(blocks, b => { if (b.type === type) found = true; });
  return found;
}

function walk(blocks, fn) {
  for (const b of blocks || []) {
    fn(b);
    if (Array.isArray(b.children)) walk(b.children, fn);
  }
}

function renderBlocks() {
  $('#workflowName').value = activeWorkflow.name;
  $('#blocks').innerHTML = `<div class="drop-zone root-drop" data-drop-container="root">Workflow gyökér szint</div>` +
    renderBlockList(activeWorkflow.blocks, 0, null) +
    `<div class="drop-zone root-drop" data-drop-container="root">Ide húzhatsz blokkot a fő szintre</div>`;
  bindBlockEvents();
}

function renderBlockList(blocks, level, parentId) {
  if (!blocks || !blocks.length) return level ? '<div class="empty nested-empty">Húzz ide blokkokat, vagy jelöld ki a konténert és adj hozzá blokkot a bal oldalon.</div>' : '<div class="empty">Adj hozzá blokkokat a bal oldali palettából.</div>';
  return blocks.map((b, idx) => {
    const childHtml = CONTAINERS.has(b.type) ? `<div class="container-body" data-drop-container="${b.id}">
      <div class="container-label">A blokk hatása alá tartozó behúzott blokkok</div>
      ${renderBlockList(b.children || [], level + 1, b.id)}
    </div>` : '';
    return `<div class="block-wrap" data-wrap="${b.id}" style="--level:${level}">
      <div class="block block-${b.type} ${b.id===selectedBlockId?'selected':''}" draggable="true" data-block="${b.id}" data-parent="${parentId || 'root'}">
        <div class="block-actions">
          <button class="small" title="Fel" data-up="${b.id}">↑</button>
          <button class="small" title="Le" data-down="${b.id}">↓</button>
          ${parentId ? `<button class="small" title="Kihúzás fő szintre" data-outdent="${b.id}">⇤</button>` : ''}
          ${b.type!=='trigger'?`<button class="small danger" title="Törlés" data-del="${b.id}">×</button>`:''}
        </div>
        <div class="row"><span class="pill">${level ? '↳' : idx+1}</span><span class="block-title">${escapeHtml(BF.blockTitle(b))}</span></div>
        <div class="block-desc">${escapeHtml(BF.blockDesc(b))}</div>
      </div>
      ${childHtml}
    </div>`;
  }).join('');
}

function bindBlockEvents() {
  document.querySelectorAll('[data-block]').forEach(el => {
    el.onclick = e => { if (e.target.tagName !== 'BUTTON') { selectedBlockId = el.dataset.block; renderAll(); }};
    el.ondragstart = e => {
      e.dataTransfer.setData('text/plain', el.dataset.block);
      e.dataTransfer.effectAllowed = 'move';
    };
    el.ondragover = e => { e.preventDefault(); e.stopPropagation(); el.classList.add('drop-before'); };
    el.ondragleave = () => el.classList.remove('drop-before');
    el.ondrop = e => {
      e.preventDefault(); e.stopPropagation(); el.classList.remove('drop-before');
      const id = e.dataTransfer.getData('text/plain');
      moveBefore(id, el.dataset.block);
    };
  });
  document.querySelectorAll('[data-drop-container]').forEach(zone => {
    zone.ondragover = e => { e.preventDefault(); e.stopPropagation(); zone.classList.add('drop-active'); };
    zone.ondragleave = () => zone.classList.remove('drop-active');
    zone.ondrop = e => {
      e.preventDefault(); e.stopPropagation(); zone.classList.remove('drop-active');
      const id = e.dataTransfer.getData('text/plain');
      moveInto(id, zone.dataset.dropContainer);
    };
  });
  document.querySelectorAll('[data-up]').forEach(b => b.onclick = e => { e.stopPropagation(); reorder(b.dataset.up, -1); });
  document.querySelectorAll('[data-down]').forEach(b => b.onclick = e => { e.stopPropagation(); reorder(b.dataset.down, 1); });
  document.querySelectorAll('[data-outdent]').forEach(b => b.onclick = e => { e.stopPropagation(); outdentToRoot(b.dataset.outdent); });
  document.querySelectorAll('[data-del]').forEach(b => b.onclick = e => { e.stopPropagation(); deleteBlock(b.dataset.del); });
}

function listForContainer(containerId) {
  if (!containerId || containerId === 'root') return activeWorkflow.blocks;
  const found = findBlock(containerId)?.block;
  if (!found || !CONTAINERS.has(found.type)) return null;
  found.children ||= [];
  return found.children;
}

function findBlock(id, blocks = activeWorkflow.blocks, parent = null) {
  if (!id) return null;
  for (let i = 0; i < (blocks || []).length; i++) {
    const b = blocks[i];
    if (b.id === id) return { block: b, list: blocks, index: i, parent };
    const child = findBlock(id, b.children || [], b);
    if (child) return child;
  }
  return null;
}

function removeBlock(id) {
  const found = findBlock(id);
  if (!found || found.block.type === 'trigger') return null;
  return found.list.splice(found.index, 1)[0];
}

function isDescendant(containerId, possibleChildId) {
  const container = findBlock(containerId)?.block;
  let yes = false;
  walk(container?.children || [], b => { if (b.id === possibleChildId) yes = true; });
  return yes;
}

function moveInto(id, containerId) {
  if (!id) return;
  if (containerId !== 'root') {
    const target = findBlock(containerId)?.block;
    if (!target || !CONTAINERS.has(target.type)) return;
    if (id === containerId || isDescendant(id, containerId)) return alert('Egy blokk nem húzható saját maga alá.');
  }
  const item = removeBlock(id);
  if (!item) return;
  const list = listForContainer(containerId);
  list.push(item);
  selectedBlockId = item.id;
  markDirty();
  renderAll();
}

function moveBefore(id, beforeId) {
  if (!id || id === beforeId) return;
  if (isDescendant(id, beforeId)) return alert('Egy konténer nem húzható saját gyermekblokkja elé.');
  const before = findBlock(beforeId);
  const item = removeBlock(id);
  if (!before || !item) return;
  const updatedBefore = findBlock(beforeId);
  const insertAt = updatedBefore ? updatedBefore.index : before.index;
  const list = updatedBefore ? updatedBefore.list : before.list;
  list.splice(insertAt, 0, item);
  selectedBlockId = item.id;
  markDirty();
  renderAll();
}

function reorder(id, dir) {
  const found = findBlock(id);
  if (!found) return;
  const j = found.index + dir;
  if (j < 0 || j >= found.list.length) return;
  [found.list[found.index], found.list[j]] = [found.list[j], found.list[found.index]];
  markDirty();
  renderAll();
}

function outdentToRoot(id) {
  const item = removeBlock(id);
  if (!item) return;
  activeWorkflow.blocks.push(item);
  selectedBlockId = item.id;
  markDirty();
  renderAll();
}

function deleteBlock(id) {
  removeBlock(id);
  selectedBlockId = firstBlock(activeWorkflow.blocks)?.id;
  markDirty();
  renderAll();
}

function markDirty() {
  if (activeWorkflow.imported) activeWorkflow.verified = false;
}

function renderInspector() {
  const b = findBlock(selectedBlockId)?.block;
  if (!b) { $('#inspector').innerHTML = '<div class="empty">Válassz blokkot.</div>'; return; }
  let html = `<div class="list-title">${escapeHtml(BF.BLOCKS[b.type]?.name || b.type)}</div>`;
  if (['click','fill','extract','watchElement'].includes(b.type)) html += targetEditor(b);
  if (b.type === 'click') html += checkboxField('confirmRisky','Kockázatos kattintásnál kérjen megerősítést', b.confirmRisky !== false) + numberField('timeoutMs','Max várakozás ms', b.timeoutMs || 5000);
  if (b.type === 'fill') html += valueSourceHelp() + textArea('value','Mit illesszen be?', b.value || '') + numberField('timeoutMs','Max várakozás ms', b.timeoutMs || 5000);
  if (b.type === 'extract') html += selectField('extractMode','Mit nyerjen ki?', b.extractMode || 'text', [['text','Látható szöveg'],['value','Mezőérték']]) + textField('varName','Változó neve', b.varName || 'adat') + numberField('timeoutMs','Max várakozás ms', b.timeoutMs || 5000);
  if (b.type === 'watchText') html += textField('text','Figyelt szöveg vagy karakter', b.text || '') + numberField('timeoutMs','Timeout ms', b.timeoutMs || 30000) + checkboxField('caseSensitive','Kis/nagybetű számítson', Boolean(b.caseSensitive));
  if (b.type === 'watchElement') html += numberField('timeoutMs','Timeout ms', b.timeoutMs || 30000);
  if (b.type === 'wait') html += selectField('waitMode','Várakozás típusa', b.waitMode || 'time', [['time','Idő'],['text','Szöveg megjelenése'],['element','Elem megjelenése']]) + (b.waitMode === 'time' ? numberField('ms','Idő ms', b.ms || 1000) : b.waitMode === 'text' ? textField('text','Szöveg', b.text || '') + numberField('timeoutMs','Timeout ms', b.timeoutMs || 5000) : targetEditor(b) + numberField('timeoutMs','Timeout ms', b.timeoutMs || 5000));
  if (b.type === 'ifBlock') html += selectField('conditionMode','Feltétel', b.conditionMode || 'textExists', [['textExists','Szöveg létezik'],['elementExists','Elem létezik'],['valueContains','Elem értéke tartalmazza']]) + (b.conditionMode === 'elementExists' || b.conditionMode === 'valueContains' ? targetEditor(b) : '') + (b.conditionMode === 'valueContains' ? textField('value','Keresett érték', b.value || '') : b.conditionMode === 'textExists' ? textField('text','Keresett szöveg', b.text || '') : '') + numberField('timeoutMs','Elemkeresési timeout ms', b.timeoutMs || 1000) + `<div class="status">Az alá behúzott blokkok csak akkor futnak, ha a feltétel igaz. Gyermek blokkok: ${(b.children||[]).length}</div>`;
  if (b.type === 'repeatBlock') html += numberField('repeatCount','Ismétlések száma', b.repeatCount || 2) + `<div class="status">Az alá behúzott blokkok ismétlődnek. Gyermek blokkok: ${(b.children||[]).length}</div>`;
  if (b.type === 'popupWait') html += numberField('timeoutMs','Popup timeout ms', b.timeoutMs || 10000) + `<button id="testPopup" class="ghost">Popup tesztelése</button>`;
  if (b.type === 'popupExtract') html += selectField('extractMode','Mit nyerjen ki?', b.extractMode || 'text', [['text','Teljes popup szöveg'],['title','Popup cím']]) + textField('varName','Változó neve', b.varName || 'popup_szoveg');
  if (b.type === 'popupClick') html += textField('buttonText','Popup gomb szövege', b.buttonText || 'OK') + numberField('timeoutMs','Timeout ms', b.timeoutMs || 5000);
  if (b.type === 'copy') html += valueSourceHelp() + textArea('value','Mit másoljon?', b.value || '');
  if (b.type === 'email') html += textField('to','Címzett', b.to || '') + textField('subject','Tárgy', b.subject || '') + textArea('body','Törzs', b.body || '') + textField('resultName','Draft változó neve', b.resultName || 'email_draft');
  if (b.type === 'openEmail') html += textField('draftName','Email draft változó', b.draftName || 'email_draft') + numberField('maxUrlLength','Mailto max hossz', b.maxUrlLength || 1800) + `<div class="status">Az extension nem küld emailt. Csak mailto ablakot nyit; hosszú törzs esetén vágólapra másol.</div>`;
  if (CONTAINERS.has(b.type)) html += `<div class="hr"></div><div class="status">Tipp: húzz blokkokat a blokk alatti behúzott területre, vagy hagyd kijelölve ezt a blokkot és adj hozzá új blokkot a bal oldali palettából.</div>`;
  html += `<div class="hr"></div><button id="testBlock" class="ghost">Blokk tesztelése</button>`;
  $('#inspector').innerHTML = html;
  $('#inspector').querySelectorAll('[data-field]').forEach(input => {
    const handler = () => updateField(input.dataset.field, input.type === 'checkbox' ? input.checked : input.value);
    input.oninput = handler; input.onchange = handler;
  });
  const pick = $('#pickElement'); if (pick) pick.onclick = () => startPick(b.id, 'target');
  const test = $('#testBlock'); if (test) test.onclick = () => testBlock(b);
  const popupTest = $('#testPopup'); if (popupTest) popupTest.onclick = testPopup;
}

function targetEditor(b){ return `<div class="field"><label>Cél elem</label><div class="status">${b.target ? escapeHtml(b.target.label + ' · ' + b.target.tag) : 'Nincs elem kiválasztva'}</div><button id="pickElement" class="primary">Elem kiválasztása az oldalról</button></div>`; }
function valueSourceHelp(){ return `<div class="status">Használható változók: {{email}}, {{nev}}, {{popup_szoveg}}. A jobb oldali változóra kattintva vágólapra másolódik.</div>`; }
function textField(field,label,value){ return `<div class="field"><label>${label}</label><input data-field="${field}" value="${escapeAttr(value)}"></div>`; }
function numberField(field,label,value){ return `<div class="field"><label>${label}</label><input data-field="${field}" type="number" value="${escapeAttr(value)}"></div>`; }
function checkboxField(field,label,value){ return `<label class="check"><input data-field="${field}" type="checkbox" ${value?'checked':''}> ${label}</label>`; }
function textArea(field,label,value){ return `<div class="field"><label>${label}</label><textarea data-field="${field}">${escapeHtml(value)}</textarea></div>`; }
function selectField(field,label,value,options){ return `<div class="field"><label>${label}</label><select data-field="${field}">${options.map(([v,l])=>`<option value="${v}" ${v===value?'selected':''}>${l}</option>`).join('')}</select></div>`; }
function updateField(field, value) {
  const b = findBlock(selectedBlockId)?.block;
  if (!b) return;
  b[field] = ['timeoutMs','ms','maxUrlLength','repeatCount'].includes(field) ? Number(value) : value;
  markDirty();
  renderBlocks();
  renderVariables();
  renderImportWarning();
  if (['waitMode','conditionMode'].includes(field)) renderInspector();
}

function renderVariables() {
  $('#variables').innerHTML = BF.collectVariables(activeWorkflow).map(v => `<span class="var-chip" data-var="${v}">{{${v}}}</span>`).join('');
  document.querySelectorAll('[data-var]').forEach(chip => chip.onclick = async () => { await navigator.clipboard.writeText(`{{${chip.dataset.var}}}`); $('#log').textContent = `Változó vágólapra másolva: {{${chip.dataset.var}}}`; });
}

async function startPick(blockId, field) {
  await refreshTarget();
  const res = await BF.sendToTarget({ type: 'BF_START_PICKER', context: { source: 'builder', workflowId: activeWorkflow.id, blockId, field } }, targetTabId);
  if (!res.ok) alert(res.error || 'Nem sikerült elindítani az elemkiválasztást.');
}

chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'BF_ELEMENT_PICKED' && msg.context?.source === 'builder') {
    const b = findBlock(msg.context.blockId)?.block;
    if (b) { b[msg.context.field || 'target'] = msg.element; selectedBlockId = b.id; markDirty(); renderAll(); $('#log').textContent = `Elem kiválasztva: ${msg.element.label}`; }
  }
});

async function testBlock(b) {
  await refreshTarget();
  if (b.target) {
    const res = await BF.sendToTarget({ type: 'BF_TEST_TARGET', target: b.target }, targetTabId);
    $('#log').textContent = res.response?.ok ? `Teszt OK: ${res.response.element.label}` : `Teszt hiba: elem nem található`;
  } else if (b.type === 'popupWait' || b.type === 'popupExtract' || b.type === 'popupClick') {
    await testPopup();
  } else $('#log').textContent = 'Ehhez a blokkhoz nincs külön cél elem. Használd a Dry-run futtatást.';
}
async function testPopup() { await refreshTarget(); const res = await BF.sendToTarget({ type: 'BF_TEST_POPUP' }, targetTabId); $('#log').textContent = res.response?.ok ? `Popup találva:\n${res.response.text}` : `Nem találtam popupot.`; }

function reidBlocks(blocks) {
  for (const b of blocks || []) {
    b.id = crypto.randomUUID();
    if (Array.isArray(b.children)) reidBlocks(b.children);
  }
}

async function saveCurrent(){ activeWorkflow.name = $('#workflowName').value || 'Névtelen automatizmus'; workflows = workflows.map(w => w.id === activeWorkflow.id ? activeWorkflow : w); await BF.saveWorkflow(activeWorkflow); const store = await BF.getStore(); workflows = store.workflows; }
async function runCurrent(dryRun=false) {
  await saveCurrent(); await refreshTarget();
  if (!dryRun && (activeWorkflow.verified === false || activeWorkflow.imported)) {
    if (!confirm('Ez importált vagy nem ellenőrzött automatizmus. Javasolt előbb Dry-run módban tesztelni. Mégis futtatod?')) return;
  }
  $('#log').textContent = dryRun ? 'Dry-run futtatás...' : 'Futtatás...';
  const res = await BF.sendToTarget({ type: 'BF_RUN_WORKFLOW', workflow: activeWorkflow, options: { dryRun } }, targetTabId);
  $('#log').textContent = res.response?.ok ? `Kész.${dryRun?' [dry-run]':''}\n${JSON.stringify(res.response.result.vars, null, 2)}\n\n${(res.response.result.log || []).join('\n')}` : `Hiba: ${res.response?.error || res.error}`;
}

$('#workflowName').oninput = () => { activeWorkflow.name = $('#workflowName').value; renderWorkflowList(); };
$('#saveWorkflow').onclick = async () => { await saveCurrent(); $('#log').textContent = 'Mentve.'; renderAll(); };
$('#newWorkflow').onclick = async () => { await saveCurrent(); const w = BF.DEFAULT_WORKFLOW(); workflows.push(w); activeWorkflow = w; selectedBlockId = w.blocks[0].id; await BF.saveWorkflow(w); renderAll(); };
$('#duplicateWorkflow').onclick = async () => { const w = JSON.parse(JSON.stringify(activeWorkflow)); w.id = crypto.randomUUID(); w.name += ' másolat'; w.imported = false; w.verified = true; reidBlocks(w.blocks); workflows.push(w); activeWorkflow = w; selectedBlockId = firstBlock(w.blocks)?.id; await BF.saveWorkflow(w); renderAll(); };
$('#markVerified').onclick = async () => { activeWorkflow.verified = true; activeWorkflow.imported = false; await saveCurrent(); renderAll(); $('#log').textContent = 'Automatizmus ellenőrzöttként jelölve.'; };
$('#runWorkflow').onclick = () => runCurrent(false);
$('#dryRunWorkflow').onclick = () => runCurrent(true);
$('#stopRun').onclick = async () => { const res = await BF.sendToTarget({ type: 'BF_STOP_RUN' }, targetTabId); $('#log').textContent = res.ok ? 'Stop kérés elküldve.' : (res.error || 'Stop hiba.'); };
$('#exportOne').onclick = () => BF.downloadJson(`${safeFile(activeWorkflow.name)}.json`, BF.exportPayload([activeWorkflow]));
$('#exportAll').onclick = () => BF.downloadJson(`blockflow-backup.json`, BF.exportPayload(workflows));
$('#importBtn').onclick = () => $('#importFile').click();
$('#importFile').onchange = async e => {
  const f = e.target.files[0]; if (!f) return;
  try {
    const payload = JSON.parse(await f.text());
    const analysis = BF.analyzeImport(payload);
    $('#importPreview').textContent = `Import előnézet:\nSéma: ${analysis.schemaVersion}\nWorkflow-k: ${analysis.rawCount}\n\n` + analysis.workflows.map(w => `- ${w.name}: ${w.blockCount} blokk, ${w.riskyCount} kockázatos/módosító blokk\n  Típusok: ${w.blocks.join(', ')}`).join('\n');
    if (!confirm(`${analysis.rawCount} workflow importálható. Importálod?`)) return;
    const imported = await BF.importPayload(payload);
    const store = await BF.getStore(); workflows = store.workflows; activeWorkflow = workflows.find(w => w.id === store.activeWorkflowId); normalizeWorkflow(activeWorkflow); selectedBlockId = firstBlock(activeWorkflow.blocks)?.id; renderAll(); $('#log').textContent = `${imported.length} workflow importálva. Első futtatás előtt Dry-run javasolt.`;
  } catch(err) { alert(err.message); } finally { e.target.value=''; }
};

function escapeHtml(s){return String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
function escapeAttr(s){return escapeHtml(s).replace(/'/g,'&#39;');}
function safeFile(s){return String(s||'automation').toLowerCase().replace(/[^a-z0-9_-]+/g,'-').replace(/^-|-$/g,'') || 'automation';}
function safeHost(url){ try { return new URL(url).hostname; } catch { return url || 'ismeretlen'; } }

init();
